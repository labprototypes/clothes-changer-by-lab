"use client";
import { useMemo, useReducer, useState } from "react";
import { Mode, GenerationPayload } from "@/lib/types";
import ModeSelector from "@/components/ModeSelector";
import ClothesSection from "@/components/ClothesSection";
import ReferenceSection from "@/components/ReferenceSection";
import UserImageSection from "@/components/UserImageSection";
import PresetStyleSelect from "@/components/PresetStyleSelect";
import OptionsPanel from "@/components/OptionsPanel";
import GenerateButton from "@/components/GenerateButton";
import ResultPreview from "@/components/ResultPreview";

type FileItem = { file: File; comment?: string };

type State = {
  mode: Mode;
  presetStyle: GenerationPayload["presetStyle"];
  brief?: string;
  clothes: {
    top: FileItem[];
    bottom: FileItem[];
    shoes: FileItem[];
    accessories: FileItem[];
  };
  refs: { light: FileItem[]; color: FileItem[]; style: FileItem[]; comments: { light?: string; color?: string; style?: string } };
  user: FileItem[];
  options: GenerationPayload["options"];
};

type Action =
  | { type: "setMode"; mode: Mode }
  | { type: "setBrief"; brief: string }
  | { type: "addFiles"; key: keyof State["clothes"]; files: File[] }
  | { type: "removeFile"; key: keyof State["clothes"]; index: number }
  | { type: "setFileComment"; key: keyof State["clothes"]; index: number; comment: string }
  | { type: "addRef"; key: "light" | "color" | "style"; files: File[] }
  | { type: "removeRef"; key: "light" | "color" | "style"; index: number }
  | { type: "setRefComment"; key: "light" | "color" | "style"; comment: string }
  | { type: "addUser"; files: File[] }
  | { type: "removeUser"; index: number }
  | { type: "setUserComment"; index: number; comment: string }
  | { type: "setPreset"; value: State["presetStyle"] }
  | { type: "setOptions"; options: Partial<State["options"]> };

const MAX_FILE_MB = Number(process.env.NEXT_PUBLIC_MAX_FILE_MB || 15);

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "setMode":
      return { ...state, mode: action.mode };
    case "setBrief":
      return { ...state, brief: action.brief };
    case "addFiles": {
      const arr = [...state.clothes[action.key]];
      for (const f of action.files) arr.push({ file: f });
      return { ...state, clothes: { ...state.clothes, [action.key]: arr } } as State;
    }
    case "removeFile": {
      const arr = state.clothes[action.key].filter((_, i) => i !== action.index);
      return { ...state, clothes: { ...state.clothes, [action.key]: arr } } as State;
    }
    case "setFileComment": {
      const arr = state.clothes[action.key].map((it, i) => (i === action.index ? { ...it, comment: action.comment } : it));
      return { ...state, clothes: { ...state.clothes, [action.key]: arr } } as State;
    }
    case "addRef": {
      const arr = [...state.refs[action.key]];
      for (const f of action.files) arr.push({ file: f });
      return { ...state, refs: { ...state.refs, [action.key]: arr } } as State;
    }
    case "removeRef": {
      const arr = state.refs[action.key].filter((_, i) => i !== action.index);
      return { ...state, refs: { ...state.refs, [action.key]: arr } } as State;
    }
    case "setRefComment":
      return { ...state, refs: { ...state.refs, comments: { ...state.refs.comments, [action.key]: action.comment } } } as State;
    case "addUser": {
      const arr = [...state.user];
      for (const f of action.files) if (arr.length < 3) arr.push({ file: f });
      return { ...state, user: arr };
    }
    case "removeUser":
      return { ...state, user: state.user.filter((_, i) => i !== action.index) };
    case "setUserComment":
      return { ...state, user: state.user.map((it, i) => (i === action.index ? { ...it, comment: action.comment } : it)) };
    case "setPreset":
      return { ...state, presetStyle: action.value };
    case "setOptions":
      return { ...state, options: { ...state.options, ...action.options } };
    default:
      return state;
  }
}

const initial: State = {
  mode: "text",
  presetStyle: "street",
  brief: "",
  clothes: { top: [], bottom: [], shoes: [], accessories: [] },
  refs: { light: [], color: [], style: [], comments: {} },
  user: [],
  options: { seedMode: "random", neutralLight: true, highDetail: true }
};

export default function Page() {
  const [state, dispatch] = useReducer(reducer, initial);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const totalImages = useMemo(() =>
    state.clothes.top.length + state.clothes.bottom.length + state.clothes.shoes.length + state.clothes.accessories.length +
    state.refs.light.length + state.refs.color.length + state.refs.style.length + state.user.length, [state]
  );

  const starts = useMemo(()=>{
    const s: Record<string, number> = {};
    let n = 1;
    s.top = n; n += state.clothes.top.length;
    s.bottom = n; n += state.clothes.bottom.length;
    s.shoes = n; n += state.clothes.shoes.length;
    s.accessories = n; n += state.clothes.accessories.length;
    s.light = n; n += state.refs.light.length;
    s.color = n; n += state.refs.color.length;
    s.style = n; n += state.refs.style.length;
    s.user = n;
    return s as any;
  }, [state]);

  const validateBeforeSend = () => {
    if (state.mode === "replace" && state.user.length === 0) {
      setError("Для режима замены необходимо загрузить фото пользователя");
      return false;
    }
    setError(null);
    return true;
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Dashboard — Батчи</h1>
      <p className="muted">Переключайтесь между режимами, загружайте элементы одежды и референсы. Максимальный размер файла — {MAX_FILE_MB}MB.</p>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Clothes */}
        <section className="card p-4">
          <h2 className="section-title mb-3">Одежда</h2>
          <div className="space-y-4">
            <ClothesSection startIndex={starts.top} title="Верх" files={state.clothes.top} onAdd={(fs)=>dispatch({type:"addFiles", key:"top", files: fs})} onRemove={(i)=>dispatch({type:"removeFile", key:"top", index:i})} onComment={(i,c)=>dispatch({type:"setFileComment", key:"top", index:i, comment:c})} />
            <ClothesSection startIndex={starts.bottom} title="Низ" files={state.clothes.bottom} onAdd={(fs)=>dispatch({type:"addFiles", key:"bottom", files: fs})} onRemove={(i)=>dispatch({type:"removeFile", key:"bottom", index:i})} onComment={(i,c)=>dispatch({type:"setFileComment", key:"bottom", index:i, comment:c})} />
            <ClothesSection startIndex={starts.shoes} title="Обувь" files={state.clothes.shoes} onAdd={(fs)=>dispatch({type:"addFiles", key:"shoes", files: fs})} onRemove={(i)=>dispatch({type:"removeFile", key:"shoes", index:i})} onComment={(i,c)=>dispatch({type:"setFileComment", key:"shoes", index:i, comment:c})} />
            <ClothesSection startIndex={starts.accessories} title="Аксессуары" files={state.clothes.accessories} onAdd={(fs)=>dispatch({type:"addFiles", key:"accessories", files: fs})} onRemove={(i)=>dispatch({type:"removeFile", key:"accessories", index:i})} onComment={(i,c)=>dispatch({type:"setFileComment", key:"accessories", index:i, comment:c})} />
          </div>
        </section>

        {/* Middle: Mode and refs */}
        <section className="card p-4 space-y-4">
          <ModeSelector mode={state.mode} onChange={(m)=>dispatch({type:"setMode", mode:m})} />
          <ReferenceSection 
            refs={state.refs}
            onAdd={(k,fs)=>dispatch({type:"addRef", key:k, files:fs})}
            onRemove={(k,i)=>dispatch({type:"removeRef", key:k, index:i})}
            onComment={(k,c)=>dispatch({type:"setRefComment", key:k, comment:c})}
            starts={{ light: starts.light as any, color: starts.color as any, style: starts.style as any }}
          />
          <div>
            <label className="section-title">Текстовый бриф</label>
            <textarea className="mt-2 w-full rounded-xl border border-gray-200 p-3" rows={4} placeholder="Коротко опишите желаемый образ, если нужно" value={state.brief} onChange={(e)=>dispatch({type:"setBrief", brief: e.target.value})} />
          </div>
          <UserImageSection startIndex={starts.user as any} files={state.user} onAdd={(fs)=>dispatch({type:"addUser", files:fs})} onRemove={(i)=>dispatch({type:"removeUser", index:i})} onComment={(i,c)=>dispatch({type:"setUserComment", index:i, comment:c})} required={state.mode === "replace"} />
        </section>

        {/* Right: Actions */}
        <section className="card p-4 space-y-4">
          <PresetStyleSelect value={state.presetStyle} onChange={(v)=>dispatch({type:"setPreset", value: v})} />
          <OptionsPanel options={state.options} onChange={(o)=>dispatch({type:"setOptions", options:o})} />
          <GenerateButton 
            disabled={loading}
            error={error}
            onClick={async ()=>{
              if (!validateBeforeSend()) return;
              setLoading(true);
              setResult(null);
              try {
                // Build JSON payload
                const payload: GenerationPayload = {
                  mode: state.mode === "refs" && state.brief ? "refs" : state.mode,
                  presetStyle: state.presetStyle,
                  brief: state.brief || undefined,
                  clothes: {
                    top: state.clothes.top.map(({comment})=>({comment})),
                    bottom: state.clothes.bottom.map(({comment})=>({comment})),
                    shoes: state.clothes.shoes.map(({comment})=>({comment})),
                    accessories: state.clothes.accessories.map(({comment})=>({comment}))
                  },
                  references: {
                    light: { items: state.refs.light.map(({comment})=>({comment})), comment: state.refs.comments.light },
                    color: { items: state.refs.color.map(({comment})=>({comment})), comment: state.refs.comments.color },
                    style: { items: state.refs.style.map(({comment})=>({comment})), comment: state.refs.comments.style }
                  },
                  userImages: state.user.map(({comment})=>({comment})),
                  options: state.options
                };

                const form = new FormData();
                form.append("json", JSON.stringify(payload));
                // precise keys
                const appendMany = (prefix: string, items: FileItem[]) => items.forEach((it, i)=> form.append(`files${prefix}[${i}]`, it.file, it.file.name));
                appendMany("[top]", state.clothes.top);
                appendMany("[bottom]", state.clothes.bottom);
                appendMany("[shoes]", state.clothes.shoes);
                appendMany("[accessories]", state.clothes.accessories);
                appendMany("[refs][light]", state.refs.light);
                appendMany("[refs][color]", state.refs.color);
                appendMany("[refs][style]", state.refs.style);
                appendMany("[user]", state.user);

                const res = await fetch("/api/generate", { method: "POST", body: form });
                if (!res.ok) throw new Error(`${res.status}`);
                const data = await res.json();
                setResult(data.imageBase64);
              } catch (e:any) {
                setError(`Ошибка генерации: ${e.message}`);
              } finally {
                setLoading(false);
              }
            }}
            loading={loading}
            totalImages={totalImages}
          />
          <ResultPreview base64={result} />
        </section>
      </div>
    </div>
  );
}

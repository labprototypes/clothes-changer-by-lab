import "@/styles/globals.css";
import { ReactNode } from "react";

export const metadata = {
  title: "Facechanger Dashboard",
  description: "Прототип сервиса замены одежды и генерации образов"
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className="bg-soft text-ink">
      <body className="min-h-screen">
        <header className="sticky top-0 z-20 bg-white/70 backdrop-blur border-b border-gray-100">
          <div className="mx-auto max-w-7xl px-6 py-4 flex items-center justify-between">
            <div className="text-lg font-semibold">Facechanger</div>
            <nav className="flex gap-2">
              <a className="px-3 py-1.5 rounded-full bg-primary text-ink font-medium" href="#">Dashboard</a>
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-7xl px-6 py-8">{children}</main>
      </body>
    </html>
  );
}
